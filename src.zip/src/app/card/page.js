// components/Card.js
const Card = ({ title, value, icon }) => (
    <div className="bg-black p-4 rounded-2xl shadow-lg flex flex-col items-center justify-center text-center">
      <div className="text-3xl text-blue-500 mb-3">{icon}</div>
      <h3 className="text-lg font-semibold text-gray-800 mb-1">{title}</h3>
      <p className="text-gray-600">{value}</p>
    </div>
  );
  
  export default Card;
  