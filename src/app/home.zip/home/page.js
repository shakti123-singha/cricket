"use client";

import React, { useState } from "react";
import Image from "next/image";
import './home.css'


const Home = () => {
  const [showDetails, setShowDetails] = useState(false);

  const toggleDetails = () => {
    setShowDetails(!showDetails);
  };

  return (
    <div className={homePage}>
      <video className={style
    .homeVideo} autoPlay muted loop>
        <source src="/image/ipl.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <div className={`container ${style .contentContainer}`}>
        <div className={textContent}>
          <div className={card}>
            <h1>Ready for IPL 2025 with Reddy Anna Book!</h1>
            <p className={summary}>
              The top cricket players worldwide will gather on one platform in IPL 2025. For cricket enthusiasts, the
              2025 IPL is expected to be an exciting journey of thrill, competition, and promoting new talent that makes
              all the difference. Multiple competitive teams are expected to compete for the trophy in the tournament.
              Innovations such as enhanced analytics for players, fan interaction programs, and digital broadcasting
              will redefine the experience at IPL.
            </p>
            {showDetails && (
              <p className={details}>
                One of the main events will be the IPL 2025 auction, where teams come together to assemble teams with a
                mix of established players and emerging talent. Advanced decision-making technology including
                AI-powered analytics along with real-time tracking of player performances also adds to the excitement.
                <br />
                <br />
                Online cricket betting is one of the attractions a cricket enthusiast would look for in IPL as the game
                gets newer and newer with time. Cricket Online ID also provides an opportunity to start cricket betting.
              </p>
            )}
            <button onClick={toggleDetails} className={btnCustom}>
              {showDetails ? "Read Less" : "Read More"}
            </button>
          </div>
        </div>
        <div className={imageContent}>
          <Image src="/image/imgipl.png" alt="IPL 2025 Highlights" width={400} height={300} className={style
        .image} />
        </div>
      </div>
    </div>
  );
};

export default Home;
