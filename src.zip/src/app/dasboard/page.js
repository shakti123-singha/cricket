import { MdOutlineScoreboard, MdSchedule, MdLeaderboard, MdUpcoming, MdOutlineSignalWifiStatusbar4Bar } from "react-icons/md";
import React from 'react'

export default function childCOMPONENT() {
  return (
    <>
    <Card/>
    <Dashboard/>
    </>
  )
}





const Card = ({ title, value, icon }) => (
  <div className="bg-white p-4 rounded-2xl shadow-lg flex flex-col items-center justify-center text-center">
    <div className="text-3xl text-blue-500 mb-3">{icon}</div>
    <h3 className="text-lg font-semibold text-gray-800 mb-1">{title}</h3>
    <p className="text-gray-600">{value}</p>
  </div>
);

// Dashboard Component
export const Dashboard = () => (
  <div className="flex flex-col bg-gray-100 p-6">
    {/* Dashboard Cards */}
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <Card title="Live Score" value="8" icon={<MdOutlineScoreboard />} />
      <Card title="Upcoming Matches" value="5" icon={<MdUpcoming />} />
      <Card title="Ranking" value="Top 10" icon={<MdLeaderboard />} />
      <Card title="Status" value="Active" icon={<MdOutlineSignalWifiStatusbar4Bar />} />
    </div>

    {/* Content Sections */}
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white p-6 rounded-2xl shadow-lg">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activities</h2>
        <p>Recent activity details or charts go here.</p>
      </div>
      <div className="bg-white p-6 rounded-2xl shadow-lg">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Performance</h2>
        <p>Performance metrics or graphs go here.</p>
      </div>
    </div>
  </div>
);