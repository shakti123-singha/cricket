import DataTable from "../datatable/page";
export const mockLiveScores = [
    { id: 1, team1: 'Team A', team2: 'Team B', score: '150/4' },
    { id: 2, team1: 'Team C', team2: 'Team D', score: '120/3' },
    { id: 3, team1: 'Team E', team2: 'Team F', score: '180/6' },
    { id: 4, team1: 'Team G', team2: 'Team H', score: '90/2' },
  ];

<DataTable data={mockLiveScores}/>
  