'use client';

import { useState } from 'react';
import Link from 'next/link';
import { FaBars } from "react-icons/fa6";
import { MdOutlineScoreboard, MdSchedule, MdLeaderboard, MdUpcoming, MdOutlineSignalWifiStatusbar4Bar } from "react-icons/md";
import { TbLivePhoto } from "react-icons/tb";
import { IoNewspaperOutline } from "react-icons/io5";

// Card Component
const Card = ({ title, value, icon }) => (
  <div className="bg-white p-4 rounded-2xl shadow-lg flex flex-col items-center justify-center text-center">
    <div className="text-3xl text-blue-500 mb-3">{icon}</div>
    <h3 className="text-lg font-semibold text-gray-800 mb-1">{title}</h3>
    <p className="text-gray-600">{value}</p>
  </div>
);

// Dashboard Component
const Dashboard = () => (
  <div className="flex flex-col bg-gray-100 p-6">
    {/* Dashboard Cards */}
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <Card title="Live Score" value="8" icon={<MdOutlineScoreboard />} />
      <Card title="Upcoming Matches" value="5" icon={<MdUpcoming />} />
      <Card title="Ranking" value="Top 10" icon={<MdLeaderboard />} />
      <Card title="Status" value="Active" icon={<MdOutlineSignalWifiStatusbar4Bar />} />
    </div>

    {/* Content Sections */}
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white p-6 rounded-2xl shadow-lg">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activities</h2>
        <p>Recent activity details or charts go here.</p>
      </div>
      <div className="bg-white p-6 rounded-2xl shadow-lg">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Performance</h2>
        <p>Performance metrics or graphs go here.</p>
      </div>
    </div>
  </div>
);

export default function Layout() {
  const [isSidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="h-screen flex">
      {/* Sidebar */}
      <aside
        className={`bg-gray-800 text-white transition-all duration-300 ${isSidebarOpen ? 'w-64' : 'w-16'} h-full flex flex-col fixed top-0 left-0`}
      >
        <button className="text-xl p-4" onClick={() => setSidebarOpen(!isSidebarOpen)}>
          <FaBars />
        </button>
        <ul className="space-y-4 mt-4 px-4">
          {[
            { href: '/livescore', icon: <MdOutlineScoreboard />, label: 'Live Score' },
            { href: '/commentary', icon: <TbLivePhoto />, label: 'Commentary' },
            { href: '/latest-news', icon: <IoNewspaperOutline />, label: 'Latest News' },
            { href: '/records', icon: <MdSchedule />, label: 'Records' },
            { href: '/ranking', icon: <MdLeaderboard />, label: 'Ranking' },
            { href: '/upcoming', icon: <MdUpcoming />, label: 'Upcoming Matches' },
            { href: '/status', icon: <MdOutlineSignalWifiStatusbar4Bar />, label: 'Status' },
          ].map(({ href, icon, label }) => (
            <li key={href}>
              <Link href={href} className="flex items-center gap-2 hover:text-gray-300">
                {icon}
                {isSidebarOpen && <span>{label}</span>}
              </Link>
            </li>
          ))}
        </ul>
      </aside>

      {/* Main Content */}
      <div className={`ml-${isSidebarOpen ? '64' : '16'} transition-all duration-300 flex-1 flex flex-col`}>        
        {/* Top Navbar */}
        <nav className="bg-gray-800 text-white flex justify-between items-center px-6 py-4" style={{ marginLeft: isSidebarOpen ? '4rem' : '1rem' }}>
          <h1 className="text-lg font-bold">Dashboard</h1>
          <div className="flex gap-4">
            <Link href="/" className="hover:text-gray-300">Home</Link>
            <Link href="/about" className="hover:text-gray-300">About</Link>
          </div>
        </nav>

        {/* Dashboard Content */}
        <main className="flex-1 bg-gray-100 overflow-auto p-6">
          <Dashboard />
        </main>
      </div>
    </div>
  );
}
