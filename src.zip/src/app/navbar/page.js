// components/Navbar.js
"use client";

import Link from 'next/link';

const Navbar = () => (
  <nav className="bg-gray-800 text-white flex justify-between items-center px-6 py-4">
    <h1 className="text-lg font-bold">Dashboard</h1>
    <div className="flex gap-4">
      <Link href="/" className="hover:text-gray-300">Home</Link>
      <Link href="/about" className="hover:text-gray-300">About</Link>
    </div>
  </nav>
);

export default Navbar;
