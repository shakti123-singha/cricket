// // pages/dashboard.js
// "use client";

// import { useState, useEffect } from 'react';
// import Sidebar from './components/Sidebar';
// import Navbar from './components/Navbar';
// import Card from './components/Card';
// import DataTable from './components/DataTable';
// import axios from 'axios';
// import { MdOutlineScoreboard, MdUpcoming, MdLeaderboard, MdOutlineSignalWifiStatusbar4Bar } from 'react-icons/md';

// const Dashboard = () => {
//   const [isSidebarOpen, setSidebarOpen] = useState(true);
//   const [data, setData] = useState([]);

//   // Fetch data from API
//   useEffect(() => {
//     axios.get('https://api.example.com/data')  // Replace with your actual API URL
//       .then(response => setData(response.data))
//       .catch(error => console.error('Error fetching data:', error));
//   }, []);

//   return (
//     <div className="h-screen flex">
//       {/* Sidebar - Pass the setSidebarOpen function here */}
//       <Sidebar isSidebarOpen={isSidebarOpen} setSidebarOpen={setSidebarOpen} />

//       {/* Main Content */}
//       <div className={`ml-${isSidebarOpen ? '64' : '16'} transition-all duration-300 flex-1 flex flex-col`}>
//         {/* Top Navbar */}
//         <Navbar />

//         {/* Dashboard Content */}
//         <div className="flex flex-col bg-gray-100 p-6">
//           {/* Dashboard Cards */}
//           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
//             <Card title="Live Score" value="8" icon={<MdOutlineScoreboard />} />
//             <Card title="Upcoming Matches" value="5" icon={<MdUpcoming />} />
//             <Card title="Ranking" value="Top 10" icon={<MdLeaderboard />} />
//             <Card title="Status" value="Active" icon={<MdOutlineSignalWifiStatusbar4Bar />} />
//           </div>

//           {/* Data Table */}
//           <DataTable data={data} />
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dashboard;
