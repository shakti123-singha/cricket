'use client';

import { useState } from 'react';
import Link from 'next/link';
import { FaBars } from "react-icons/fa6";

import { TbLivePhoto } from "react-icons/tb";
import { IoNewspaperOutline } from "react-icons/io5";
// import Dashboard from '../dasboard/page';

// <Dashboard/>

export default function Layout() {
  const [isSidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="h-screen flex">
      {/* Sidebar */}
      <aside
        className={`bg-gray-800 text-white transition-all duration-300 ${isSidebarOpen ? 'w-64' : 'w-16'} h-full flex flex-col fixed top-0 left-0`}
      >
        <button className="text-xl p-4" onClick={() => setSidebarOpen(!isSidebarOpen)}>
          <FaBars />
        </button>
        <ul className="space-y-4 mt-4 px-4">
          {[
            { href: '/livescore', icon: <MdOutlineScoreboard />, label: 'Live Score' },
            { href: '/commentary', icon: <TbLivePhoto />, label: 'Commentary' },
            { href: '/latest-news', icon: <IoNewspaperOutline />, label: 'Latest News' },
            { href: '/records', icon: <MdSchedule />, label: 'Records' },
            { href: '/ranking', icon: <MdLeaderboard />, label: 'Ranking' },
            { href: '/upcoming', icon: <MdUpcoming />, label: 'Upcoming Matches' },
            { href: '/status', icon: <MdOutlineSignalWifiStatusbar4Bar />, label: 'Status' },
          ].map(({ href, icon, label }) => (
            <li key={href}>
              <Link href={href} className="flex items-center gap-2 hover:text-gray-300">
                {icon}
                {isSidebarOpen && <span>{label}</span>}
              </Link>
            </li>
          ))}
        </ul>
      </aside>

     
      </div>
    
  );
}
